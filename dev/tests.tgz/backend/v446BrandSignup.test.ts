// v446 (Ravi, 15 Nov 2026): brand sign-up revamp — business type, QualifiedBrand / BriefPosted, 3 screens, brand funnel,
// role=brand links straight into the brand sign-up.
import { describe, it, expect } from "vitest";
import fs from "fs";
import { judgeBrand, hasWebsite, cleanBusinessType, assessNewBrand, briefPostedOnce, briefPostedMiddleware, readBrandInfo } from "./brandQuality";
import { rememberIgLookup, igLookupResult } from "./instagramConnect";
import { buildBrandFunnel, countBrandSignupVisit, readBrandSignupVisits } from "./brandFunnel";

const read = (f: string) => fs.readFileSync(f, "utf8");
const fresh = () => new Date().toISOString();

describe("v446 · QualifiedBrand rules", () => {
  it("creator never qualifies; IG under 100 or private → unverified; 300+ or website → qualified", () => {
    expect(judgeBrand({ businessType: "creator", igHandle: "x", ig: { found: true, followers: 9000 }, website: "a.com" }).quality).toBe("plain");
    expect(judgeBrand({ businessType: "shop", igHandle: "x", ig: { found: false, followers: null }, website: "shop.in" }).quality).toBe("unverified");
    expect(judgeBrand({ businessType: "shop", igHandle: "x", ig: { found: true, followers: 99 }, website: "shop.in" }).quality).toBe("unverified");
    expect(judgeBrand({ businessType: "d2c", igHandle: "x", ig: { found: true, followers: 300 }, website: "" }).quality).toBe("qualified");
    expect(judgeBrand({ businessType: "cafe", igHandle: "", ig: null, website: "https://cafe.in" }).quality).toBe("qualified");
    expect(judgeBrand({ businessType: "salon", igHandle: "x", ig: { found: true, followers: 150 }, website: "" }).quality).toBe("plain");
    expect(judgeBrand({ businessType: "", igHandle: "", ig: null, website: "a.com" }).quality).toBe("plain");
  });
  it("an Instagram / linktree link is not a website", () => {
    expect(hasWebsite("instagram.com/brand")).toBe(false);
    expect(hasWebsite("https://linktr.ee/brand")).toBe(false);
    expect(hasWebsite("brand.co.in")).toBe(true);
    expect(hasWebsite("hello")).toBe(false);
    expect(cleanBusinessType("D2C")).toBe("d2c");
    expect(cleanBusinessType("bank")).toBe("");
  });
  it("Instagram's own answer is remembered per username", () => {
    rememberIgLookup("@Some.Brand", true, 420);
    expect(igLookupResult("some.brand")).toEqual({ found: true, followers: 420 });
    rememberIgLookup("hidden_one", false, null);
    expect(igLookupResult("hidden_one")).toEqual({ found: false, followers: null });
    expect(igLookupResult("never_asked_xyz")).toBe(null);
  });
  it("sign-up: event once for a qualified new brand, kept as brandinfo; unverified gets no event", async () => {
    rememberIgLookup("qbrand446", true, 1200);
    const u = { user_id: "b446a", role: "brand", created_at: fresh(), email: "a@b.c" };
    const r1 = await assessNewBrand({ user: u, data: { business_type: "d2c", instagram_handle: "qbrand446" } });
    expect(r1.verdict.quality).toBe("qualified");
    expect(r1.event).toEqual({ name: "QualifiedBrand", event_id: "qb_b446a", followers: 1200 });
    const r2 = await assessNewBrand({ user: u, data: { business_type: "d2c", instagram_handle: "qbrand446" } });
    expect(r2.event).toBe(null);
    expect((await readBrandInfo("b446a"))?.business_type).toBe("d2c");

    rememberIgLookup("private446", false, null);
    const r3 = await assessNewBrand({ user: { ...u, user_id: "b446b" }, data: { business_type: "shop", instagram_tried: "private446", website: "shop.in" } });
    expect(r3.verdict.quality).toBe("unverified");
    expect(r3.event).toBe(null);
    expect((await readBrandInfo("b446b"))?.quality).toBe("unverified");
  });
  it("an old account never fires QualifiedBrand", async () => {
    const r = await assessNewBrand({ user: { user_id: "b446old", role: "brand", created_at: "2025-01-01T00:00:00Z" }, data: { business_type: "app", website: "app.io" } });
    expect(r.verdict.quality).toBe("qualified");
    expect(r.event).toBe(null);
  });
});

describe("v446 · BriefPosted", () => {
  it("first brief only, brands only, not for unverified brands", async () => {
    expect(await briefPostedOnce({ user: { user_id: "c1", role: "creator" }, kind: "campaign" })).toBe(null);
    const ev = await briefPostedOnce({ user: { user_id: "b446c", role: "brand" }, kind: "ugc_brief" });
    expect(ev?.name).toBe("BriefPosted");
    expect(ev?.event_id).toBe("bp_b446c");
    expect(await briefPostedOnce({ user: { user_id: "b446c", role: "brand" }, kind: "campaign" })).toBe(null);
    expect(await briefPostedOnce({ user: { user_id: "b446b", role: "brand" }, kind: "campaign" })).toBe(null); // unverified above
  });
  it("middleware adds meta_event to a successful POST /campaigns answer only", async () => {
    const mw = briefPostedMiddleware(async () => ({ user_id: "b446d", role: "brand" }));
    const run = (path: string, status: number, body: any) => new Promise<any>((resolve) => {
      const res: any = { statusCode: status, json: (b: any) => { resolve(b); return res; } };
      mw({ method: "POST", path }, res, () => res.json(body));
    });
    expect(await run("/campaigns", 400, { error: "x" })).toEqual({ error: "x" });
    expect(await run("/campaigns/1/update", 200, { ok: 1 })).toEqual({ ok: 1 });
    const ok = await run("/campaigns", 200, { ok: true });
    expect(ok.meta_event?.name).toBe("BriefPosted");
    expect((await run("/ugc/briefs", 200, { ok: true })).meta_event).toBeUndefined();
  });
  it("is wired on the API router and the brief routes are untouched", () => {
    expect(read("backend/server.ts")).toContain("router.use(briefPostedMiddleware(parseAuthUser))");
    expect(read("backend/campaigns_routes.ts")).not.toContain("BriefPosted");
    expect(read("backend/ugc_routes.ts")).not.toContain("BriefPosted");
  });
  it("browser / app fire the same event ids", () => {
    const s = read("src/lib/metaPixel.js");
    expect(s).toContain('"QualifiedBrand", "BriefPosted"');
    expect(read("backend/auth_routes.ts")).toContain("assessNewBrand(");
  });
});

describe("v446 · brand funnel", () => {
  it("counts sign-up page → account → steps → done → first brief", () => {
    const now = Date.parse("2026-11-15T10:00:00Z");
    const t = "2026-11-10T10:00:00Z";
    const users = [
      { user_id: "a", role: "brand", created_at: t }, { user_id: "b", role: "brand", created_at: t },
      { user_id: "c", role: "brand", created_at: t }, { user_id: "d", role: "creator", created_at: t },
      { user_id: "old", role: "brand", created_at: "2026-01-01T00:00:00Z" },
    ];
    const out = buildBrandFunnel({
      visits: 10, users, brands: [{ user_id: "a", company_name: "A" }],
      progress: [{ user_id: "b", flow: "brand_mobile", page: "business" }, { user_id: "c", flow: "brand_mobile", page: "identity" }],
      campaigns: [{ brand_user_id: "a" }], ugcOrders: [],
      brandInfo: [{ user_id: "a", quality: "qualified", business_type: "d2c" }, { user_id: "b", quality: "unverified", business_type: "shop" }],
      days: 30, now,
    });
    expect(out.rows.map((r) => r.count)).toEqual([10, 3, 3, 2, 1, 1, 1]);
    expect(out.rows[1].ofPrev).toBe(30);
    expect(out.qualified).toBe(1);
    expect(out.unverifiedIds).toEqual(["b"]);
    expect(out.byType).toEqual({ d2c: 1, shop: 1 });
  });
  it("sign-up page visits are counted per day", async () => {
    const before = await readBrandSignupVisits(1);
    await countBrandSignupVisit();
    expect(await readBrandSignupVisits(1)).toBe(before + 1);
  });
  it("admin route + card exist", () => {
    expect(read("backend/admin_growth_routes.ts")).toContain('"/admin/growth/brand-funnel"');
    expect(read("src/components/admin/growth/FunnelPanel.jsx")).toContain("<BrandFunnelCard />");
  });
});

describe("v446 · screens", () => {
  it("phone sign-up is 3 screens with a required business type and a creator switch", () => {
    const s = read("src/pages/onboarding/BrandOnboardingMobile.jsx");
    expect(s).toContain("What do you run?");
    expect(s).toContain('disabled={!formData.businessType}');
    expect(s).toContain("goCreator");
    expect(s).not.toMatch(/screen === [4-7] &&/);
    expect(s).toContain("TRUSTED_BY");
    expect(s).toContain("business_type: formData.businessType");
  });
  it("desktop has the business type and funnel steps", () => {
    const s = read("src/components/onboarding/BrandOnboardingFlow.jsx");
    expect(s).toContain('useFunnelSteps(published ? pageTotal + 1 : pageNum, pageTotal + 1, "brand_desktop")');
    expect(s).toContain("What do you run? *");
    expect(s).toContain("business_type: formData.businessType");
  });
  it("old questions moved to a Brand Home card", () => {
    expect(read("src/pages/brand/BrandHomeMobile.jsx")).toContain("<BrandMatchCard");
    expect(read("src/pages/brand/BrandHomeMobile.jsx").split("\n").length).toBeLessThanOrEqual(1600);
  });
});
