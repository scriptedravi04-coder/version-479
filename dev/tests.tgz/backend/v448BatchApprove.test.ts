// v448 (Ravi: 235 selected → "Couldn't approve the selected applications"): bulk approve goes 10 at a time
// with a longer timeout, and the server skips rows that are already approved (no second email on retry).
import { describe, it, expect } from "vitest";
import fs from "fs";
import path from "path";

const read = (f: string) => fs.readFileSync(path.join(__dirname, "..", f), "utf8");

describe("v448 · bulk approve in small batches", () => {
  it("screen sends 10 ids per call with a 2-minute timeout and shows progress", () => {
    const s = read("src/components/admin/WaitlistManager.jsx");
    expect(s).toMatch(/const CHUNK = 10;/);
    expect(s).toMatch(/batch-approve', \{ ids: part \}, \{ timeout: 120000 \}/);
    expect(s).toMatch(/Approving \$\{Math\.min\(i \+ CHUNK/);
  });
  it("server skips already-approved rows instead of approving + emailing again", () => {
    const s = read("backend/admin_waitlist_routes.ts");
    const i = s.indexOf("/admin/waitlist/batch-approve");
    const body = s.slice(i, i + 2500);
    expect(body).toMatch(/=== 'approved'\) \{ results\.push\(\{ id: targetId, ok: true, already: true \}\); continue; \}/);
    expect(body.indexOf("already: true")).toBeLessThan(body.indexOf("approveCreatorApplication("));
  });
});

describe("v448 · approval email has website + Play Store", () => {
  it("claim button goes to the website sign-up, plus a Play Store link with role=creator", () => {
    const s = read("backend/creatorApplication.ts");
    expect(s).toMatch(/claimLink = `\$\{appUrl\}\/signup\?role=creator&email=/);
    expect(s).toMatch(/play\.google\.com\/store\/apps\/details\?id=com\.ybex\.app&referrer=\$\{encodeURIComponent\("role=creator/);
    expect(s).toMatch(/signatureHtml: `\$\{appRow\}/);
  });
});

describe("v448 · Waitlist 'Email about Ybex' invite + who joined", () => {
  it("server route queues a waitlist_selected broadcast for the picked rows only (full admin, real emails, unsubscribe respected)", () => {
    const s = read("backend/emailBroadcasts.ts");
    expect(s).toMatch(/router\.post\("\/admin\/waitlist\/email-selected"/);
    expect(s).toMatch(/audience: "waitlist_selected"/);
    expect(s).toMatch(/if \(!isRealEmail\(e\)\) \{ noEmail\+\+; continue; \}/);
    expect(s).toMatch(/if \(unsub\.has\(e\)\) \{ unsubscribed\+\+; continue; \}/);
    expect(s).toMatch(/r\.joined = true/);
    expect(s).toMatch(/u\.auth_method !== "unclaimed"/);
  });
  it("audience broadcasts still exclude CSV-imported contacts", () => {
    expect(read("backend/emailBroadcasts.ts")).toMatch(/src\.csvImported\.has\(e\)\) return;/);
  });
  it("Waitlist screen has the button, the ready invite with referral + utm, and the report shows Joined", async () => {
    const w = read("src/components/admin/WaitlistManager.jsx");
    expect(w).toMatch(/✉️ Email about Ybex/);
    expect(w).toMatch(/admin\/waitlist\/email-selected/);
    const { INVITE_DEFAULT } = await import("../src/components/admin/WaitlistManager");
    expect(INVITE_DEFAULT.ctaUrl).toContain("ref=YBEX-DB946998");
    expect(INVITE_DEFAULT.ctaUrl).toContain("utm_campaign=waitlist_invite");
    expect(INVITE_DEFAULT.bodyText).toContain("play.google.com/store/apps/details?id=com.ybex.app");
    expect(read("src/components/admin/BroadcastReport.jsx")).toMatch(/have joined Ybex so far/);
  });
  it("Play Store install referrer keeps the inviter's ref code", () => {
    expect(read("src/lib/signupSource.js")).toMatch(/if \(q\.get\("ref"\)\) rememberReferral\(q\.get\("ref"\)\)/);
  });
});

describe("v448 · Admin referral page made simple", () => {
  it("shows only referral results, top inviters and who brought whom (names, not ids)", () => {
    const s = read("src/components/admin/AdminReferralProgram.jsx");
    expect(s).not.toMatch(/Creator numbers/);
    expect(s).toMatch(/Referral results/);
    expect(s).toMatch(/Top inviters/);
    expect(s).toMatch(/Who brought whom/);
    expect(s).toMatch(/r\.referrer_name/);
    const b = read("backend/referralProgram.ts");
    expect(b).toMatch(/top_referrers:/);
    expect(b).toMatch(/referrer_name: a\.name/);
  });
  it("rewards are sentences grouped by trigger, with every setting still editable", () => {
    const s = read("src/components/admin/AdminReferralProgram.jsx");
    for (const t of ["1. A creator invites a creator", "2. Someone invites a brand", "3. Limits (stop misuse)", "More settings (older bonus rewards)"]) expect(s).toContain(t);
    for (const k of ["signups_per_reward","free_deals_per_reward","free_deals_valid_days","featured_days","share_pct_of_earnings","share_cap_per_creator","min_withdraw","monthly_cap_per_user","friend_reward","friend_reward_cap","brand_invite_reward","brand_invite_max_brands","brand_invite_min_deal","brand_invite_unlock_deals","brand_invite_featured_days"])
      expect(s).toContain(`k="${k}"`);
  });
});
