// v475 (iOS QA #3): Sign in with Apple token kept on sign-in and revoked on account delete.
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import crypto from "crypto";
import fs from "fs";
import path from "path";

const { privateKey, publicKey } = crypto.generateKeyPairSync("ec", { namedCurve: "P-256" });
const pem = privateKey.export({ type: "pkcs8", format: "pem" }).toString();
const ENV = { APPLE_CLIENT_ID: "in.ybexmedia.signin", APPLE_TEAM_ID: "TEAM123456", APPLE_KEY_ID: "KEY1234567", APPLE_PRIVATE_KEY: pem.replace(/\n/g, "\\n") };

describe("v475 Apple revoke", () => {
  let saved: Record<string, any>;
  beforeEach(() => { saved = { ...process.env }; Object.assign(process.env, ENV); });
  afterEach(() => { process.env = saved; });

  it("client secret is a valid ES256 token for Apple", async () => {
    const { appleClientSecret, appleRevokeReady } = await import("./oauth_routes");
    expect(appleRevokeReady()).toBe(true);
    const jwt = appleClientSecret(process.env, 1_700_000_000_000);
    const [h, b, s] = jwt.split(".");
    expect(JSON.parse(Buffer.from(h, "base64url").toString())).toEqual({ alg: "ES256", kid: "KEY1234567" });
    const claims = JSON.parse(Buffer.from(b, "base64url").toString());
    expect(claims).toMatchObject({ iss: "TEAM123456", sub: "in.ybexmedia.signin", aud: "https://appleid.apple.com", iat: 1_700_000_000 });
    expect(crypto.verify("sha256", Buffer.from(`${h}.${b}`), { key: publicKey, dsaEncoding: "ieee-p1363" }, Buffer.from(s, "base64url"))).toBe(true);
  });

  it("keeps the token on sign-in and revokes it on delete; nothing without the key", async () => {
    const { keepAppleToken, revokeAppleFor } = await import("./oauth_routes");
    const post = vi.fn(async (u: string, _b?: any) => (u.endsWith("/token") ? { data: { refresh_token: "rt-1" } } : { data: {} }));
    expect(await keepAppleToken("A@x.in", "code1", "https://ybexmedia.in/api/auth/oauth/apple/callback", post)).toBe(true);
    expect(post.mock.calls[0][1]).toContain("grant_type=authorization_code");
    expect(await revokeAppleFor("a@x.in", post)).toBe(true);
    expect(post.mock.calls[1][0]).toBe("https://appleid.apple.com/auth/revoke");
    expect(post.mock.calls[1][1]).toContain("token=rt-1");
    expect(await revokeAppleFor("a@x.in", post)).toBe(false); // already gone
    delete process.env.APPLE_PRIVATE_KEY;
    expect(await keepAppleToken("b@x.in", "c", "", post)).toBe(false);
    expect(post).toHaveBeenCalledTimes(2);
  });

  it("account delete calls the revoke", () => {
    const src = fs.readFileSync(path.join(__dirname, "account_routes.ts"), "utf8");
    expect(src).toContain("void revokeAppleFor(email);");
  });
});

describe("v477 push for every account on a phone", () => {
  it("one per phone (open account first), extra rows say whose and open that account", async () => {
    const { onePerPhone, accountPayload, phoneEndpoint, ACCT_MARK } = await import("./push_routes");
    const subs = [{ endpoint: `apns:aa${ACCT_MARK}c1`, user_id: "c1" }, { endpoint: "apns:aa", user_id: "b1" }, { endpoint: "fcm:zz", user_id: "c1" }];
    const one = onePerPhone(subs);
    expect(one.length).toBe(2);
    expect(one.find((s: any) => phoneEndpoint(s.endpoint) === "apns:aa").user_id).toBe("b1");
    const p = accountPayload({ title: "2 creators applied", url: "/brand/ugc?id=4", tag: "n1" }, "c1", "Ravi Kumar Sharma");
    expect(p.title).toBe("Ravi Kumar · 2 creators applied");
    expect(p.url).toBe("/brand/ugc?id=4&yb_acct=c1");
    expect(accountPayload({ title: "x" }, "c1", "").url).toBe("/notifications?yb_acct=c1");
    const src = fs.readFileSync(path.join(__dirname, "push_routes.ts"), "utf8");
    expect(src).toContain("const extra = Boolean(req.body?.extra) && Boolean(user);");
  });
});
