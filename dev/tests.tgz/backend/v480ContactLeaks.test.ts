// v480 (Ravi, 25 Nov chat screenshots): numbers that still got through the chat filter.
import { describe, it, expect, beforeEach } from "vitest";
import { checkComprehensiveDisallowedContent as c, resetRecentMessageBuffer, hasMaskedMobile, fillerDigitRuns, asksToMoveOffYbex, chunkDigits } from "./contactSecurityFilter";

describe("v480 contact leaks", () => {
  beforeEach(() => resetRecentMessageBuffer());
  it("blocks the real leaks from the screenshots", () => {
    for (const m of ["9*90790*1105 please msg me on this number", "96h 35h 95h 77h 38h", "Wp no de rha hu udhar text kro", "Aap ek kaam kro mai wp", "Wp mai send kr deta hu aapko", "meri wp no di hai udhar text kijiye", "98xxx 12x45 call", "whatsapp pe baat karte hai", "telegram pe aa jao"]) {
      resetRecentMessageBuffer();
      expect(c(m).blocked, m).toBe(true);
    }
  });
  it("a number split as digits then number words", () => {
    expect(c("995083", { threadId: "t", senderId: "s", now: 1 }).blocked).toBe(false);
    expect(c("Nine nine five zero", { threadId: "t", senderId: "s", now: 2 }).blocked).toBe(true);
    expect(chunkDigits("Nine nine five zero")).toBe("9950");
    expect(chunkDigits("Nice work")).toBe(null);
  });
  it("normal deal talk still goes through", () => {
    for (const m of ["Deliverable: 1 reel + whatsapp status share", "I will post 3 reels in 5 days", "Budget 15000, 2 reels", "Order id 12345 67890", "My rate is ₹8,000 for 1 reel", "Shoot on 12/12/2026 at 5 pm", "Send me the brief please", "can you share drive link", "Wow nice work", "Draft ready, 2 videos 30s each", "Reel 1 at 9:30, reel 2 at 10:30, reel 3 at 11:30"]) {
      resetRecentMessageBuffer();
      expect(c(m).blocked, m).toBe(false);
    }
    expect(hasMaskedMobile("₹5,000 x 2 reels")).toBe(false);
    expect(fillerDigitRuns("2 reels 3 stories")).toEqual([]);
    expect(asksToMoveOffYbex("share on whatsapp status")).toBe(false);
  });
});
