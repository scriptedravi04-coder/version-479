import { describe, it, expect } from "vitest";
import { isRealPayment, isTestPayment, isInhousePayment, creatorNiches, bulkImportDays, buildGrowthReport,
  classifyAttempt, paidLater, attemptSummary, reminderDueAt, outOfQuietHours, reminderText, reminderLink } from "./adminGrowth";

const IST = 5.5 * 3600000;
const ist = (s: string) => Date.parse(s + "Z") - IST; // "2026-11-25T10:00:00" in IST

describe("v481 money: test payments are not money", () => {
  it("test order is out, in-house is in but flagged", () => {
    const test = { status: "SUCCESS", zaakpay_order_id: "order_test_1_x", gross_amount: 13000 };
    const inh = { status: "SUCCESS", zaakpay_order_id: "order_inhouse_ab", gross_amount: 1000 };
    expect(isTestPayment(test)).toBe(true);
    expect(isRealPayment(test)).toBe(false);
    expect(isRealPayment(inh)).toBe(true);
    expect(isInhousePayment(inh)).toBe(true);
  });
  it("report GMV leaves the ₹13,000 test out and splits in-house", () => {
    const r: any = buildGrowthReport({
      transactions: [
        { id: "1", status: "SUCCESS", zaakpay_order_id: "order_test_1", gross_amount: 13000, platform_fee_amount: 1300, created_at: new Date().toISOString() },
        { id: "2", status: "SUCCESS", zaakpay_order_id: "order_inhouse_1", gross_amount: 1000, platform_fee_amount: 0, created_at: new Date().toISOString() },
      ],
    } as any, new Date());
    expect(r.money.gmv).toBe(1000);
    expect(r.money.netRevenue).toBe(0);
    expect(r.money.inhouse.gmv).toBe(1000);
    expect(r.money.brandPaidGmv).toBe(0);
    expect(r.money.testExcluded.amount).toBe(13000);
    expect(r.investor.totals.brandPaid).toBe(0);
  });
  it("categories read primary_niche", () => {
    expect(creatorNiches({ primary_niche: "Beauty", niche: "Go to settings to add" })).toEqual(["Beauty"]);
  });
  it("a 533-account day is an import", () => {
    const users = [...Array(533)].map(() => ({ created_at: "2026-11-16T06:00:00Z" }))
      .concat([...Array(10)].map((_, i) => ({ created_at: `2026-11-${10 + i}T06:00:00Z` })));
    expect([...bulkImportDays(users)]).toEqual(["2026-11-16"]);
  });
});

describe("v481 payment attempts", () => {
  const order = (id: string, status: string, extra: any = {}) => ({ id, status, amount: 250000, created_at: 1764000000, notes: { kind: "ugc_brief", brand_id: "b1" }, ...extra });
  it("paid / failed / left", () => {
    expect(classifyAttempt(order("o1", "paid")).status).toBe("paid");
    const f = classifyAttempt(order("o2", "attempted"), [{ order_id: "o2", status: "failed", error_description: "Bank declined", method: "card", created_at: 1 }]);
    expect(f.status).toBe("failed");
    expect(f.reason).toBe("Bank declined");
    expect(f.amount).toBe(2500);
    expect(classifyAttempt(order("o3", "created")).status).toBe("left");
  });
  it("a later paid order for the same brief stops reminders", () => {
    const a = classifyAttempt(order("o1", "created"));
    const b = classifyAttempt(order("o2", "paid", { created_at: 1764000500 }));
    expect(paidLater(a, [a, b])).toBe(true);
    expect(attemptSummary([a, b]).totals.opened).toBe(2);
  });
  it("2 min, 3 h, next day 7 pm — never 10 pm–9 am", () => {
    const t = ist("2026-11-25T11:00:00");
    expect(reminderDueAt(t, 1)).toBe(t + 2 * 60000);
    expect(reminderDueAt(t, 2, t + 120000)).toBe(t + 3 * 3600000);
    expect(reminderDueAt(t, 3, t + 3 * 3600000)).toBe(ist("2026-11-26T19:00:00"));
    expect(reminderDueAt(t, 4)).toBeNull();
    const late = ist("2026-11-25T21:30:00");
    expect(reminderDueAt(late, 2, late)).toBe(ist("2026-11-26T09:00:00"));
    expect(outOfQuietHours(ist("2026-11-26T02:00:00"))).toBe(ist("2026-11-26T09:00:00"));
  });
  it("punchy text, no reward promise, right link", () => {
    const x = reminderText({ status: "left", page: "ugc_brief", amount: 2500, reason: null }, 1);
    expect(x.title).toBe("You forgot to pay 👀");
    expect(x.body).toContain("₹2,500");
    for (const s of [1, 2, 3]) expect(JSON.stringify(reminderText({ status: "failed", page: "campaign_escrow", amount: 1, reason: "x" }, s))).not.toMatch(/reward|cashback|offer/i);
    expect(reminderLink({ page: "campaign_escrow" }, "c9")).toBe("/chat/c9");
    expect(reminderLink({ page: "ugc_order" })).toBe("/brand/ugc/orders");
  });
});
