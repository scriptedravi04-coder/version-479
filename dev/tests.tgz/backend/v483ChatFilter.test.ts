import { describe, it, expect, beforeEach } from "vitest";
import { checkComprehensiveDisallowedContent as c, resetRecentMessageBuffer, normalizeForFilter } from "./contactSecurityFilter";
import { checkAbusiveContent as a } from "./abuseFilter";

beforeEach(() => resetRecentMessageBuffer());
const blocked = (t: string) => c(t).blocked;

export const HIDDEN_NUMBERS = [
  "९८७६५४३२१०", "৯৮৭৬৫৪৩২১০", "۹۸۷۶۵۴۳۲۱۰", "௯௮௭௬௫௪௩௨௧௦", "𝟗𝟖𝟕𝟔𝟓𝟒𝟑𝟐𝟏𝟎", "⑨⑧⑦⑥⑤④③②①⓪", "⁹⁸⁷⁶⁵⁴³²¹⁰", "9️⃣8️⃣7️⃣6️⃣5️⃣4️⃣3️⃣2️⃣1️⃣0️⃣",
  "98765​43210", "9*8*7*6*5*4*3*2*1*0", "9🔥8🔥7🔥6🔥5🔥4🔥3🔥2🔥1🔥0", "9x8x7x6x5x4x3x2x1x0", "98ab765cd43ef210", "98765—43210",
  "नौ आठ सात छह पांच चार तीन दो एक शून्य", "nineeightsevensixfivefourthreetwoonezero", "n i n e e i g h t s e v e n s i x f i v e f o u r t h r e e t w o o n e z e r o",
  "pehle 98765 fir 43210", "last 5 digit 34456, first 99102", "0123456789 ulta padho", "4938271605 x 2", "9876543200 + 10",
  "0124 4567890", "+971 50 123 4567", "+1 415 555 2671", "nіne eіght seven six five four three two one zero",
];
export const ASKS = [
  "whatsup pe msg karo", "whats app pe aao", "wa pe msg kr dena", "WA kro", "vatsap pe baat karte", "vhatsapp pe aa jao", "wattsapp karo",
  "व्हाट्सएप पे बात करो", "green app pe aao", "hara wala app pe aa jao", "dusre app pe baat karte",
  "ybex ke bahar deal karte hai", "commission bachate hai", "platform fee bachao", "offline deal karte",
  "number deta hu", "number le lo mera", "number save kar lo", "number likh lo", "number bhej raha hu",
  "usi number pe msg karo", "purane number pe msg kr", "same number pe call", "jo number pehle diya",
  "contact do apna", "contact milega?", "aapse kaise baat ho", "aapko kaise contact karu", "numbr do", "phone kar lena",
  "insta dm karo", "Can you share poc number", "share your number please", "inbox karo", "mail kar do", "moj pe follow karo", "wp hai aapke pass?", "aap wp use karte ho?",
];
export const NORMAL = [
  "Video ko WhatsApp groups me share mat karna", "WhatsApp status pe bhi daal dena", "Is this for iPhone or Android?", "Who should I contact about shipping?",
  "2 reels and 3 stories for ₹15,000", "Budget is 5000, can do 7500 for 2 videos", "I have 89000 followers, avg reach 230000", "Deadline 12 Dec, 2 reels 30 sec each",
  "Order id 4521", "Shoot it in mobile portrait", "Brand ka insta handle tag karna hai", "number of reels kitne chahiye?", "Payment Ybex pe hi karunga",
  "Direct baat karte hai, kya chahiye aapko?", "Kal 3 baje tak bhej dunga", "Rate 1599 per reel hai", "Mere 5604 followers hain", "Seedha point pe aao",
  "Script ready hai, 45 sec ka video", "Collab kab start karein?", "Product 2 din me deliver ho jayega", "Size M aur L dono bhej do", "Please share the number of reels you can do", "Can please send me app link",
];
export const ABUSE = ["bkl", "bsdk kya kar raha", "lodu", "lavde", "jhaatu", "f*ck you", "ch*tiya", "b.c", "m.c", "motherfucker", "asshole",
  "चूतिया", "मादरचोद", "बहनचोद", "गांडू", "रंडी", "teri maa ki", "teri behen ki", "maa chuda",
  "jaan se maar dunga", "tera ghar aa ke maarunga", "acid phek dunga", "dekh lunga tujhe", "raat ko milo", "meet karo hotel me", "pic bhejo apni", "video call pe aao akele"];

describe("v483 chat filter (25 Nov report)", () => {
  it("normalises scripts, invisible characters and look-alikes", () => {
    expect(normalizeForFilter("९८७६")).toBe("9876");
    expect(normalizeForFilter("9​8")).toBe("98");
  });
  it("blocks every hidden-number trick", () => {
    const miss = HIDDEN_NUMBERS.filter((t) => { resetRecentMessageBuffer(); return !blocked(t); });
    expect(miss).toEqual([]);
  });
  it("blocks WhatsApp spellings, code words, number-giving and off-Ybex deals", () => {
    const miss = ASKS.filter((t) => { resetRecentMessageBuffer(); return !blocked(t); });
    expect(miss).toEqual([]);
  });
  it("lets normal deal talk through", () => {
    const wrong = NORMAL.filter((t) => { resetRecentMessageBuffer(); return blocked(t); });
    expect(wrong).toEqual([]);
  });
  it("blocks short-form / Hindi-script abuse, threats and creepy asks; mild words only flagged", () => {
    const miss = ABUSE.filter((t) => !a(t).blocked);
    expect(miss).toEqual([]);
    expect(a("jaan se maar dunga").code).toBe("THREAT");
    for (const w of ["harami", "kamina", "saala"]) { expect(a(w).blocked).toBe(false); expect(a(w).code).toBe("PROFANITY"); }
    for (const t of NORMAL) expect(a(t).blocked).toBe(false);
  });
});

import { strikeDecision, chatBlockedUntil, strikeReasonText } from "./chatRestriction";
describe("v483 strike system", () => {
  it("3 blocks → pause, 3 h the first time then 24 h; a threat counts as 3", () => {
    expect(strikeDecision(["PHONE", "PHONE_LEET"], 0).pause).toBe(false);
    expect(strikeDecision(["PHONE", "PHONE_LEET", "OFF_PLATFORM"], 0)).toMatchObject({ pause: true, hours: 3 });
    expect(strikeDecision(["PHONE", "PHONE", "PHONE"], 1).hours).toBe(24);
    expect(strikeDecision(["THREAT"], 0).pause).toBe(true);
    expect(strikeReasonText(["THREAT"])).toBe("a threatening message");
  });
  it("an auto pause ends after its hours; an admin Lift ends it early", () => {
    const at = new Date(Date.now() - 2 * 36e5).toISOString();
    expect(chatBlockedUntil([{ violation_type: "CHAT_AUTO_PAUSED", reason: "[3h] x", created_at: at }])).not.toBeNull();
    expect(chatBlockedUntil([{ violation_type: "CHAT_AUTO_PAUSED", reason: "[1h] x", created_at: at }])).toBeNull();
    expect(chatBlockedUntil([{ violation_type: "CHAT_AUTO_PAUSED", reason: "[3h] x", created_at: at }, { violation_type: "CHAT_UNRESTRICTED", created_at: new Date().toISOString() }])).toBeNull();
  });
});
