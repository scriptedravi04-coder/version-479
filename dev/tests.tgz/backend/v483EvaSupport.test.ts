import { it, expect } from "vitest";
import { evaTemplateReply, evaTicketReply } from "./support_routes";
it("eva", async () => {
  expect(evaTemplateReply({ category: "campaign_manager_call", ageDays: 40 })).toMatch(/^Sorry for the late reply\. .*call you soon/);
  const r = await evaTicketReply({ category: "Profile & KYC", subject: "kyc", message: "kyc kab hoga", role: "creator" });
  expect(r).toMatch(/Eva/);
});
