import { describe, it, expect } from "vitest";
import { creatorKnowledge } from "./assist_routes";
import { offerLiveAt } from "../src/lib/diwaliChallenge";
import { NUDGE_TEXT_PLAIN } from "./profileNudges";
import { peekLines } from "../src/components/feedback/evaUi.jsx";

describe("v484: no ₹300 offer after the challenge closed (15 Nov)", () => {
  const after = Date.parse("2026-11-25T10:00:00Z"), before = Date.parse("2026-11-01T10:00:00Z");
  it("Eva's creator prompt says it ended and never to promise it", () => {
    const k = creatorKnowledge(after);
    expect(k).toContain("ENDED on 15 Nov 2026");
    expect(k).toMatch(/never offer or promise ₹300/);
    expect(k).not.toContain("Lead with this");
    expect(k).not.toContain("{{CREATOR_OFFER}}");
    expect(creatorKnowledge(before)).toContain("Lead with this");
  });
  it("app surfaces stop offering it", () => {
    expect(offerLiveAt(after)).toBe(false);
    expect(JSON.stringify(peekLines("creator", "Asha"))).not.toContain("₹300");
    expect(JSON.stringify(NUDGE_TEXT_PLAIN)).not.toContain("₹300");
  });
});
