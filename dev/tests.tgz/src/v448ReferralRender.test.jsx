// v448: the simplified Admin referral page renders names, totals and the sentence-style rewards.
import React from "react";
import { describe, it, expect, vi } from "vitest";
import { render, screen, waitFor, fireEvent } from "@testing-library/react";

vi.mock("./lib/api", () => ({ api: { get: vi.fn((u) => Promise.resolve({ data: u === "admin/referral-program" ? { config: { friend_reward: 21, brand_invite_reward: 500, free_deals_per_reward: 0, featured_days: 0 }, numbers: {} }
  : u === "admin/referral-list" ? { referrals: [{ id: "r1", referrer_id: "u1", referred_id: "u2", status: "joined", created_at: "2026-11-10T10:00:00Z", referrer_name: "Ravi", referrer_code: "YBEX-DB946998", referred_name: "Priya", referred_role: "creator" }],
    summary: { joins: 1, joins_last_30_days: 1, people_inviting: 1, paid_out: 0, waiting_payout: 21, not_counted: 0 }, top_referrers: [{ user_id: "u1", name: "Ravi", code: "YBEX-DB946998", joins: 1, last_30_days: 1, last_at: "2026-11-10T10:00:00Z" }] }
  : { withdrawals: [] } })), put: vi.fn(), post: vi.fn() } }));
vi.mock("sonner", () => ({ toast: { success: vi.fn(), error: vi.fn() } }));
import AdminReferralProgram from "./components/admin/AdminReferralProgram";

describe("v448 · referral admin page", () => {
  it("renders", async () => {
    render(<AdminReferralProgram />);
    await waitFor(() => expect(screen.getByText("Referral results")).toBeTruthy());
    expect(screen.getAllByText("Ravi").length).toBeGreaterThan(0);
    expect(screen.getByText("Priya")).toBeTruthy();
    expect(screen.queryByText("Creator numbers")).toBeNull();
    expect(screen.getByTestId("ref-cfg-friend_reward").value).toBe("21");
    expect(screen.queryByTestId("ref-cfg-share_cap_per_creator")).toBeNull();
    fireEvent.click(screen.getByTestId("ref-more"));
    expect(screen.getByTestId("ref-cfg-share_cap_per_creator")).toBeTruthy();
    expect(screen.getByText("Off right now (both rewards are 0).")).toBeTruthy();
  });
});
