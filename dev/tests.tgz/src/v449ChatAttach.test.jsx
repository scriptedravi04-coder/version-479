import { describe, it, expect } from "vitest";
import { attachmentKind, attachmentLabel } from "./components/chat/mobile/MobileMessageRow";
import { readFileSync } from "fs";
import { isHomePath } from "./components/promo/PromoPopup";
import { headerAmountLabel } from "./components/chat/mobile/ChatBoxMobile";

describe("v449 chat attachments + popups (Ravi's screen recording)", () => {
  it("knows videos, photos and files", () => {
    expect(attachmentKind("chat/x/96992cc3.mov")).toBe("video");
    expect(attachmentKind("chat/x/a.MP4?t=1")).toBe("video");
    expect(attachmentKind("chat/x/a.jpg")).toBe("image");
    expect(attachmentKind("chat/x/a.pdf")).toBe("file");
  });
  it("hides the iPhone random file code", () => {
    expect(attachmentLabel("📎 Attached file: 96992cc3-711f-43c8-94df-e5d44dc3d8f0.mov", "x.mov")).toBe("📎 Video");
    expect(attachmentLabel("📎 Attached file: Brief final.pdf", "x.pdf")).toBe("📎 Attached file: Brief final.pdf");
    expect(attachmentLabel("hello", "")).toBe("hello");
  });
  it("Open file never navigates the whole app away", () => {
    const src = readFileSync("src/components/chat/mobile/MobileMessageRow.jsx", "utf8");
    expect(src).toContain("openInSheet(href)");
    expect(src).not.toMatch(/Open file<\/a>[^]*target="_blank"[^]*attachment/);
  });
  it("promo posters never pop up inside chats or deals", () => {
    const src = readFileSync("src/components/promo/PromoPopup.jsx", "utf8");
    for (const p of ['"/chat"', '"/inbox"', '"/deals/"']) expect(src).toContain(p);
  });
  it("chat header shows the price being negotiated, then the agreed one", () => {
    expect(headerAmountLabel({ latestOffer: 1500, fallback: 5000 })).toBe("Offer ₹1,500");
    expect(headerAmountLabel({ agreed: 1500, latestOffer: 1200, fallback: 5000 })).toBe("₹1,500");
    expect(headerAmountLabel({ creatorNet: 1400, latestOffer: 1500 })).toBe("₹1,400");
    expect(headerAmountLabel({ fallback: 5000 })).toBe("₹5,000");
    expect(headerAmountLabel({})).toBe("Payment");
  });
  it("promo posters only on Home", () => {
    expect(isHomePath("/dashboard")).toBe(true);
    expect(isHomePath("/dashboard/")).toBe(true);
    for (const p of ["/chat/abc", "/campaigns", "/deals/1", "/creator/settings", "/inbox"]) expect(isHomePath(p)).toBe(false);
  });
});
