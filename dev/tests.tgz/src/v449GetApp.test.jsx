import { describe, it, expect } from "vitest";
import { getAppTarget } from "./pages/GetApp";
import { showGetAppCard, GET_APP_SNOOZE_MS } from "./components/common/GetAppCard";
import { androidWebOnly } from "../backend/push_routes";

const AND = "Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36";
const IOS = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 Safari/604.1";

describe("v449 get the Play Store app", () => {
  it("/get-app sends Android browsers to Play with the tags", () => {
    const t = getAppTarget({ ua: AND, search: "?utm_source=push&utm_campaign=get_app_push" });
    expect(t.kind).toBe("play");
    expect(t.url).toContain("id=com.ybex.app");
    expect(decodeURIComponent(t.url)).toContain("utm_source=push");
  });
  it("/get-app sends iPhone, laptop and the app itself home", () => {
    expect(getAppTarget({ ua: IOS }).kind).toBe("home");
    expect(getAppTarget({ ua: "Mozilla/5.0 (Macintosh)" }).kind).toBe("home");
    expect(getAppTarget({ ua: AND, native: true }).kind).toBe("home");
  });
  it("home card only for Android browsers, snooze 3 days", () => {
    const now = 1_000_000;
    expect(showGetAppCard({ ua: AND, now })).toBe(true);
    expect(showGetAppCard({ ua: IOS, now })).toBe(false);
    expect(showGetAppCard({ ua: AND, native: true, now })).toBe(false);
    expect(showGetAppCard({ ua: AND, snoozedUntil: now + GET_APP_SNOOZE_MS, now })).toBe(false);
    expect(showGetAppCard({ ua: AND, snoozedUntil: now - 1, now })).toBe(true);
  });
  it("push audience android_web = Android browser phones without the app", () => {
    const subs = [
      { user_id: "a", endpoint: "https://fcm.googleapis.com/x", user_agent: AND },
      { user_id: "b", endpoint: "https://fcm.googleapis.com/y", user_agent: AND },
      { user_id: "b", endpoint: "fcm:tok", user_agent: "" },
      { user_id: "c", endpoint: "https://web.push.apple.com/z", user_agent: IOS },
    ];
    expect(androidWebOnly(subs, ["a", "b", "c", "d"])).toEqual(["a"]);
  });
});
