// v452 — UI audit ("Dark theme UI errors aur bugs" PDF). Static checks so these don't come back.
import { describe, it, expect } from "vitest";
import fs from "fs";
import path from "path";

const SRC = path.resolve(__dirname);
const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).flatMap((e) => {
  const p = path.join(d, e.name);
  if (e.isDirectory()) return walk(p);
  return /\.(jsx|tsx)$/.test(e.name) && !/\.test\./.test(e.name) ? [p] : [];
});
const files = walk(SRC);
const read = (rel) => fs.readFileSync(path.join(SRC, rel), "utf8");
const grepAll = (re) => files.filter((f) => re.test(fs.readFileSync(f, "utf8"))).map((f) => path.relative(SRC, f));

describe("v452 UI audit", () => {
  it("CSS names used by screens are defined (inputs/borders were transparent)", () => {
    const css = read("index.css");
    for (const v of ["--bg-primary", "--bg-secondary", "--violet-dark", "--border-subtle"]) expect(css).toContain(`${v}:`);
  });
  it("no endless ping dots, neon lime button or dark-theme dividers on white", () => {
    expect(grepAll(/animate-ping/)).toEqual([]);
    expect(grepAll(/#D1F23F/i)).toEqual([]);
    expect(grepAll(/divide-white\/5|border-b border-white\/5/)).toEqual([]);
  });
  it("no made-up security / tech labels", () => {
    expect(grepAll(/256-BIT ENCRYPTED|Bank-grade 256-bit|Encrypted & Secured via SSL|SSL Escrow Protected|STABLE CONNECTION|Real-Time Tracking Enabled|Brand Editorial Panel/)).toEqual([]);
  });
  it("contract popup: readable close button, no 'deed' theatre, spelling fixed", () => {
    for (const f of ["components/chat/AgreementSign.jsx", "components/chat/BrandAgreement.jsx"]) {
      const s = read(f);
      expect(s).not.toMatch(/COLABORATION|DEED EXECUTION|text-amber-200\/60|font-serif/);
      expect(s).toContain("Collaboration agreement");
    }
  });
  it("under-review popup and banner use the light app colours", () => {
    expect(read("components/common/UnderReviewModal.jsx")).not.toMatch(/bg-slate-900|blur-3xl|Under Review Queue/);
    expect(read("components/common/UnderReviewBanner.jsx")).not.toMatch(/amber-950|slate-900/);
  });
  it("creator onboarding is violet, not blue / Tokyo Night", () => {
    expect(grepAll(/#3B82F6|#9ece6a|#e0af68|#f7768e/i).filter((f) => f.includes("onboarding"))).toEqual([]);
  });
  it("dev bypass button can never show in a production build", () => {
    expect(read("pages/onboarding/CreatorOnboarding.tsx")).toMatch(/env\?\.DEV && \(import\.meta as any\)\.env\?\.VITE_ENABLE_DEV_BYPASS/);
  });
  it("earnings chart and stat icons fit the light card; ₹ not $", () => {
    const s = read("pages/dashboard/Earnings.jsx");
    expect(s).not.toMatch(/#1A1A24|rgba\(255,255,255,0\.05\)|DollarSign|Resolves in 24 hrs/);
  });
  it("one KYC review time everywhere (24–48 hours)", () => {
    expect(read("components/kyc/KYCStatusBanner.jsx")).toContain("24–48 hours");
    expect(read("pages/creator/settingsDesktop/KycPanel.jsx")).toContain("24–48 hours");
    expect(read("pages/kyc/KYCStatus.jsx")).toContain("24–48 hours");
  });
  it("error screen never shows a stack trace to users", () => {
    expect(read("components/ErrorBoundary.jsx")).not.toMatch(/componentStack\}/);
  });
  it("motion helpers exist and respect reduced motion", () => {
    const css = read("index.css");
    for (const c of [".yb-reveal", ".yb-sheet-up", ".yb-pop", ".yb-grow", ".yb-fade"]) expect(css).toContain(c);
    expect(css).toMatch(/\.yb-reveal, \.yb-sheet-up, \.yb-pop, \.yb-grow, \.yb-fade \{ animation: none; \}/);
  });
});
