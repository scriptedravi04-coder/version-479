// v453 — rest of the UI audit: photo fade, skeletons, tokens, no glow / gimmicks.
// @vitest-environment jsdom
import { describe, it, expect, vi } from "vitest";
import fs from "fs";
import path from "path";
import { watchImage } from "./lib/motion";

const SRC = path.resolve(__dirname);
const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).flatMap((e) => {
  const p = path.join(d, e.name);
  if (e.isDirectory()) return walk(p);
  return /\.(jsx|tsx)$/.test(e.name) && !/\.test\./.test(e.name) ? [p] : [];
});
const files = walk(SRC).filter((f) => !f.includes("landing/v2") && !/hallenge/.test(f));
const grepAll = (re) => files.filter((f) => re.test(fs.readFileSync(f, "utf8"))).map((f) => path.relative(SRC, f));
const read = (rel) => fs.readFileSync(path.join(SRC, rel), "utf8");

describe("v453 photo fade", () => {
  it("a loading photo waits, then fades in on load — never stays hidden", () => {
    vi.useFakeTimers();
    const img = document.createElement("img");
    img.setAttribute("src", "https://x/y.jpg");
    expect(watchImage(img)).toBe(true);
    expect(img.classList.contains("yb-img-wait")).toBe(true);
    img.dispatchEvent(new Event("load"));
    expect(img.classList.contains("yb-img-wait")).toBe(false);
    expect(img.classList.contains("yb-img-in")).toBe(true);
    const broken = document.createElement("img");
    broken.setAttribute("src", "https://x/z.jpg");
    watchImage(broken);
    vi.advanceTimersByTime(4100); // no load / error event at all → shown anyway
    expect(broken.classList.contains("yb-img-wait")).toBe(false);
    vi.useRealTimers();
  });
  it("skips images with no src or marked data-no-fade", () => {
    const a = document.createElement("img");
    expect(watchImage(a)).toBe(false);
    const b = document.createElement("img"); b.setAttribute("src", "x"); b.dataset.noFade = "";
    expect(watchImage(b)).toBe(false);
  });
  it("is installed once at start-up and has its CSS", () => {
    expect(read("index.jsx")).toContain("installImageFade()");
    expect(read("index.css")).toMatch(/img\.yb-img-wait \{ opacity: 0; \}/);
  });
});

describe("v453 audit leftovers", () => {
  it("no zero-offset glow shadows or coloured shadow tints", () => {
    expect(grepAll(/shadow-\[0_0_\d+px_(rgba|#)/)).toEqual([]);
  });
  it("no same-colour 'gradients'", () => {
    expect(grepAll(/from-\[var\(--violet\)\] to-\[#7C3AED\]|from-\[#7C3AED\] to-\[#7C3AED\]/)).toEqual([]);
  });
  it("loading = skeleton on settings, blog and payments (no spinner + 'Loading…' text)", () => {
    expect(read("pages/blog/BlogIndex.jsx")).not.toContain("Loading articles...");
    expect(read("pages/blog/BlogPostDetail.jsx")).not.toContain("Loading article...");
    expect(read("components/payments/BrandPaymentsMobile.jsx")).not.toContain("Loading payments…");
    expect(read("pages/creator/settingsDesktop/KycPanel.jsx")).not.toMatch(/Loader2 size=\{24\} className="animate-spin/);
  });
  it("no mono-font ALL-CAPS pills", () => {
    const bad = files.filter((f) => /className=(?:"[^"]*\bfont-mono\b[^"]*\buppercase\b[^"]*"|"[^"]*\buppercase\b[^"]*\bfont-mono\b[^"]*")/.test(fs.readFileSync(f, "utf8")));
    expect(bad).toEqual([]);
  });
});

describe("v454 re-audit", () => {
  it("one violet everywhere — no off-brand #9D7CFF / #A855F7 / indigo buttons", () => {
    expect(grepAll(/(?:bg|text|border)-\[#(?:9D7CFF|A855F7|7E22CE|4f46e5|6366F1)\]/i)).toEqual([]);
  });
  it("no ALL-CAPS violet buttons", () => {
    const bad = files.filter((f) => !f.includes("/admin/")).filter((f) => {
      const s = fs.readFileSync(f, "utf8");
      return (s.match(/className=(?:"[^"]*"|\{`[^`]*`\})/g) || []).some((c) => /bg-\[(?:var\(--violet\)|#7C3AED)\](?!\/)/.test(c) && /text-white/.test(c) && /\buppercase\b/.test(c));
    });
    expect(bad).toEqual([]);
  });
  it("creator profile sub-screens slide in (yb-screen-in), and the CSS exists", () => {
    expect((read("pages/creator/CreatorMobileProfile.jsx").match(/yb-screen-in/g) || []).length).toBeGreaterThanOrEqual(10);
    expect(read("index.css")).toMatch(/\.yb-screen-in \{ animation: ybScreenIn/);
  });
  it("popups that had no animation now fade / slide in", () => {
    for (const f of ["components/install/InstallGuideSheet.jsx", "components/signup/CreatorIgFirst.jsx", "pages/auth/VerifyEmail.jsx", "pages/brand/BrandKycMobile.jsx", "components/admin/SettleDealModal.jsx", "components/onboarding/FollowerGate.jsx"]) {
      expect(read(f)).toMatch(/yb-fade/);
    }
  });
  it("not-started KYC is not shown as a red error", () => {
    expect(read("pages/kyc/KYCStatus.jsx")).toContain('"Complete your KYC"');
    expect(read("pages/kyc/KYCStatus.jsx")).not.toContain('"Verification Required"');
  });
});

// ───────────────────────── v456: Back button / navigation + admin UI review ─────────────────────────
import { isAppEntry, closeTopPopup } from "./lib/native";
import { inAppHref } from "./lib/externalLinks";

describe("v456 · phone Back never closes the app over app-owned screens", () => {
  it("Eva, tour, onboarding steps, sheets and UGC views are app entries", () => {
    expect(isAppEntry({ eva: 1 })).toBe(true);
    expect(isAppEntry({ ybTour: 1, usr: null })).toBe(true);
    expect(isAppEntry({ ybexOnb: 3, ybexOnbPushed: true })).toBe(true);
    expect(isAppEntry({ ybexOnb: 1 })).toBe(false); // first onboarding step can still leave
    expect(isAppEntry({ ybexSheets: ["s1"] })).toBe(true);
    expect(isAppEntry({ ybexSheets: [] })).toBe(false);
    expect(isAppEntry({ usr: null, key: "x", idx: 2 })).toBe(false);
    expect(isAppEntry(null)).toBe(false);
  });
  it("no more 'URL unchanged → background the app' check", () => {
    const src = read("lib/native.js");
    expect(src).not.toMatch(/here\(\) === before/);
    expect(src).toMatch(/if \(closeTopPopup\(document\)\) return;/);
  });
  it("Back closes the popup on top with its own close button", () => {
    document.body.innerHTML = `<div role="dialog" id="d"><button aria-label="Close" id="x">x</button></div>`;
    const d = document.getElementById("d");
    d.getBoundingClientRect = () => ({ width: 100, height: 100 });
    let clicked = 0;
    document.getElementById("x").addEventListener("click", () => { clicked += 1; });
    expect(closeTopPopup(document)).toBe(true);
    expect(clicked).toBe(1);
    document.body.innerHTML = "";
    expect(closeTopPopup(document)).toBe(false);
  });
  it("onboarding Channels (linked) and Last step have a ← button", () => {
    const src = read("pages/onboarding/CreatorOnboardingMobile.jsx");
    expect(src).toMatch(/function ChannelsLinkedScreen\(\{ store, onOpenAddChannel, onNext, onBack, saving \}\)/);
    expect(src).toMatch(/stepLabel="Last step" saveLabel="Skip" onSave=\{onSkip\} filledSteps=\{4\} onBack=\{onBack\}/);
    expect(src).toMatch(/ybexOnbPushed: true/);
  });
  it("tour keeps the router's history state", () => {
    expect(read("components/whatsNew/WhatsNewPopup.jsx")).toMatch(/pushState\(\{ \.\.\.\(window\.history\.state \|\| \{\}\), ybTour: 1 \}/);
  });
  it("Home popups close on Back", () => {
    for (const f of ["components/common/KycPromptModal.jsx", "components/NotificationPopup.jsx", "components/quickActions/QuickActionsMobile.jsx",
      "components/whatsNew/WhatsNewPopup.jsx", "components/promo/PromoPopup.jsx", "components/common/PWAInstallPrompt.jsx",
      "components/dashboard/BrandDashboard.jsx", "components/layout/BottomNav.jsx", "pages/brand/brandUgc/CreateFabMenu.jsx", "components/layout/Layout.jsx",
      "components/admin/SettleDealModal.jsx", "components/admin/ReleasePayoutModal.jsx", "components/admin/WaitlistManager.jsx", "components/admin/blog/BlogList.jsx", "components/admin/KYCManager.jsx"]) {
      expect(read(f), f).toMatch(/useBackToClose\(/);
    }
  });
  it("step flows walk back a step; forms ask before losing work", () => {
    expect(read("components/campaigns/mobile/MobileCampaignCreate.jsx")).toMatch(/useStepBack\(currentView !== "published"/);
    expect(read("pages/brand/BrandCampaignCreate.jsx")).toMatch(/useStepBack\(currentStep > 1/);
    expect(read("pages/brand/BrandUGCPost.jsx")).toMatch(/useStepBack\(step > 1/);
    expect(read("pages/brand/BrandKycMobile.jsx")).toMatch(/useStepBack\(step === "contact"/);
    for (const f of ["components/profile/mobile/brand/CompanyDetailsScreen.jsx", "pages/creator/PublicCreatorApply.jsx", "pages/creator/CreatorSettings.jsx"]) expect(read(f), f).toMatch(/useLeaveGuard\(/);
  });
  it("after publish / discard the create page is replaced, not stacked", () => {
    for (const f of ["components/campaigns/mobile/MobileCampaignCreate.jsx", "pages/brand/BrandCampaignCreate.jsx"]) {
      const s = read(f);
      expect(s, f).not.toMatch(/[^(]navigate\("\/brand\/campaigns"\)/);
      expect(s, f).toMatch(/exitFlowTo\(navigate, "\/brand\/campaigns"\)/);
    }
  });
});

describe("v456 · no full app reloads for in-app moves", () => {
  const O = "https://ybexmedia.in";
  const a = (href, attrs = {}) => { const el = document.createElement("a"); el.setAttribute("href", href); for (const [k, v] of Object.entries(attrs)) el.setAttribute(k, v); return el; };
  it("same-site page links move inside the app", () => {
    expect(inAppHref(a("/help"), O)).toBe("/help");
    expect(inAppHref(a("/brand/kyc?x=1#t"), O)).toBe("/brand/kyc?x=1#t");
    expect(inAppHref(a("https://ybexmedia.in/delete-account"), O)).toBe("/delete-account");
  });
  it("leaves files, new tabs, other sites and mail links alone", () => {
    expect(inAppHref(a("/sitemap.xml"), O)).toBe("");
    expect(inAppHref(a("/api/x"), O)).toBe("");
    expect(inAppHref(a("/help", { target: "_blank" }), O)).toBe("");
    expect(inAppHref(a("/report.pdf"), O)).toBe("");
    expect(inAppHref(a("https://google.com/"), O)).toBe("");
    expect(inAppHref(a("mailto:support@ybexmedia.in"), O)).toBe("");
    expect(inAppHref(a("#top"), O)).toBe("");
    expect(inAppHref(a("/x", { download: "" }), O)).toBe("");
  });
  it("payment success refreshes the deal, not the app; logout replaces history", () => {
    expect(read("components/payments/PayNow.jsx")).toMatch(/if \(typeof onPaid === "function"\) onPaid\(\)/);
    expect(read("pages/collabs/DealDetail.jsx")).toMatch(/<PayNow onPaid=\{\(\) => loadDeal\(\)\}/);
    expect(read("components/chat/UGCContractModal.jsx")).not.toMatch(/location\.assign/);
    expect(read("components/campaigns/InviteToCampaignModal.jsx")).not.toMatch(/location\.assign/);
    for (const f of ["components/layout/Layout.jsx", "components/onboarding/FinishLater.jsx", "components/onboarding/PreStep_EmailVerify.tsx"]) expect(read(f), f).not.toMatch(/location\.href = "\/login"/);
  });
  it("bottom-nav tabs and page tabs don't stack history", () => {
    expect(read("components/layout/BottomNav.jsx")).toMatch(/navigate\(tab\.path, \{ replace: onOtherTab \}\)/);
    expect(read("pages/collabs/Collabs.jsx")).toMatch(/setSearchParams\(\{ tab: selectedTab \}, \{ replace: true \}\)/);
    expect(read("pages/brand/BrandInstantUGC.jsx")).toMatch(/setSearchParams\(\{ tab \}, \{ replace: true \}\)/);
  });
  it("campaign lists keep search / filters after Back", () => {
    expect(read("components/campaigns/mobile/CampaignsListMobile.jsx")).toMatch(/useKeptState\("campList:filters"/);
    expect(read("pages/campaigns/Campaigns.jsx")).toMatch(/useKeptState\("campDesk:catFilter"/);
    expect(read("pages/dashboard/Explore.jsx")).toMatch(/useKeptState\("exploreDesk:selectedNiches"/);
  });
});

describe("v456 · admin + UI leftovers", () => {
  it("no unbacked trust claims", () => {
    const s = read("components/TrustBadgeRotator.jsx");
    for (const t of ["100% KYC Verified Creators", "Instant Brief Publishing", "Verified Reach & Engagement", "Guaranteed 24h delivery SLA", "24-Hour Payout Processing"]) expect(s).not.toContain(t);
  });
  it("admin: no fake graph / vault wording, no browser confirm, UTR is checked", () => {
    const p = read("components/admin/AdminPayoutMobile.jsx");
    expect(p).not.toContain("adminCurveGrad");
    expect(p).not.toContain("Vault held");
    expect(read("components/admin/EscrowDashboard.jsx")).not.toContain("Safe Vault");
    expect(read("components/admin/AdminAnalytics.jsx")).not.toContain(">Growth Command Center<");
    expect(read("components/admin/AdminSignedContractModal.jsx")).not.toContain("SIGNATURE ARCHIVE");
    expect(read("components/admin/AdminReferralProgram.jsx")).toMatch(/\[A-Za-z0-9\]\{6,30\}/);
    const adminFiles = walk(path.join(SRC, "components/admin")).concat(walk(path.join(SRC, "pages/admin")));
    for (const f of adminFiles) expect(fs.readFileSync(f, "utf8"), f).not.toMatch(/window\.confirm\(/);
    expect(read("components/admin/KYCManager.jsx")).not.toContain("insertAdjacentHTML");
  });
  it("no broken backdrop-blur class anywhere", () => {
    for (const f of walk(SRC)) expect(fs.readFileSync(f, "utf8"), f).not.toContain("backdrop-blur-[3px]]");
  });
});

describe("v457 · every popup closes on Back; admin text boxes + skeletons", () => {
  it("the remaining popups wire useBackToClose", () => {
    for (const f of ["components/shared/UniversalPreviewModal.jsx", "components/deals/DealDetailDrawer.jsx", "components/shared/NotificationBell.jsx",
      "components/publicProfile/PhotoLedHeaderMobile.jsx", "components/install/InstallGuideSheet.jsx", "components/chat/SendBrief.jsx", "components/chat/UGCContractModal.jsx",
      "components/chat/chatBox/ChatBoxModals.jsx", "components/chat/chatBox/ChatBoxUploadSheet.jsx", "components/chat/chatBox/ChatBoxPaymentSheet.jsx",
      "components/chat/mobile/ChatBoxMobile.jsx", "components/portfolio/PortfolioViews.jsx", "components/signup/CreatorIgFirst.jsx", "components/payments/InvoiceModal.jsx",
      "components/campaigns/CreatorReviewInvitationModal.jsx", "pages/ChallengePage.jsx", "pages/auth/VerifyEmail.jsx", "pages/brand/BrandKycMobile.jsx",
      "pages/creator/CreatorUGCBrowse.jsx", "components/challenge/ChallengeUi.jsx", "pages/campaigns/Campaigns.jsx", "components/chat/ContractModal.jsx",
      "components/portfolio/AddCollabsScreen.jsx", "components/portfolio/TagBrandSheet.jsx", "components/help/SupportContactCard.jsx",
      "components/campaigns/RejectApplicantSheet.jsx", "components/campaigns/mobile/MobileCampaignCreate.jsx", "pages/brand/BrandCampaigns.jsx",
      "pages/creator/CreatorMobileProfile.jsx", "pages/dashboard/Earnings.jsx", "pages/campaigns/CampaignDetail.jsx"]) {
      expect(read(f), f).toMatch(/useBackToClose\(/);
    }
    const m = read("components/campaigns/mobile/MobileCampaignCreate.jsx");
    for (const v of ["showNicheSheet", "showCitySheet", "showDatePickerSheet", "showLanguageSheet", "showKycModal"]) expect(m).toContain(`useBackToClose(Boolean(${v})`);
    expect(read("components/deals/DealDetailDrawer.jsx")).toMatch(/useBackToClose\(showOtpModal/);
  });
  it("chat mobile hook sits above the early return (hook order)", () => {
    const s = read("components/chat/mobile/ChatBoxMobile.jsx");
    expect(s.indexOf('useBackToClose(activeSheet === "signedInfo"')).toBeLessThan(s.indexOf("if (!thread) return null;"));
  });
  it("admin has no browser text boxes; appPrompt exists", () => {
    for (const f of walk(path.join(SRC, "components/admin")).concat(walk(path.join(SRC, "pages/admin")))) expect(fs.readFileSync(f, "utf8"), f).not.toMatch(/window\.prompt\(/);
    expect(read("components/common/Popup.jsx")).toMatch(/export function appPrompt\(/);
  });
  it("admin loading states are skeletons", () => {
    for (const f of ["components/admin/EscrowDashboard.jsx", "components/admin/AdminPitchLeads.jsx", "components/admin/AdminPayoutMobile.jsx", "components/admin/AdminAnalytics.jsx",
      "components/admin/AdminActivityLogsTab.jsx", "components/admin/LandingContentManager.jsx", "pages/admin/Admin.jsx", "components/admin/platformTools/CouponList.jsx"]) expect(read(f), f).toMatch(/<ListSkeleton /);
    expect(read("components/admin/EscrowDashboard.jsx")).not.toContain("Loading escrow ledger & payout records...");
  });
});


import { mirrorTrustedLogos, TRUSTED_LOGO_FILES as SERVER_LOGOS } from "../backend/admin_speed_routes";
import { trustedBrands, trustedLogoError, TRUSTED_LOGO_FILES as APP_LOGOS } from "./lib/constants/trustedBrands";

describe("v457 · home brand logos come from our own bucket", () => {
  it("server copies only the missing logos, never overwrites", async () => {
    const uploads = [];
    const client = { storage: { from: () => ({
      list: async () => ({ data: [{ name: "CeJTOuI.png" }] }),
      upload: async (p, buf, o) => { uploads.push([p, buf.length, o.upsert, o.cacheControl]); return { error: null }; },
    }) } };
    const fetcher = async () => ({ ok: true, arrayBuffer: async () => new Uint8Array([1, 2, 3]).buffer });
    const r = await mirrorTrustedLogos(client, fetcher);
    expect(r.skipped).toEqual(["CeJTOuI.png"]);
    expect(r.copied.length).toBe(5);
    expect(uploads.every((u) => u[0].startsWith("trusted/") && u[2] === false && u[3] === "31536000")).toBe(true);
  });
  it("a failed download is reported, not thrown", async () => {
    const client = { storage: { from: () => ({ list: async () => ({ data: [] }), upload: async () => ({ error: null }) }) } };
    const r = await mirrorTrustedLogos(client, async () => ({ ok: false, status: 404 }));
    expect(r.failed.length).toBe(6);
  });
  it("app and server list the same files; img falls back to the old link once, then hides", () => {
    expect(APP_LOGOS).toEqual(SERVER_LOGOS);
    expect(trustedBrands[0].fallbackUrl).toBe("https://iili.io/CeJTOuI.png");
    const img = document.createElement("img"); img.src = "https://x/own.png";
    let hidden = 0;
    trustedLogoError({ target: img }, trustedBrands[0], () => { hidden += 1; });
    expect(img.src).toBe("https://iili.io/CeJTOuI.png");
    trustedLogoError({ target: img }, trustedBrands[0], () => { hidden += 1; });
    expect(hidden).toBe(1);
  });
});

describe("v457 · egress: uploads cache, signed links live longer", () => {
  it("every signed upload sets a long cache", () => {
    for (const f of ["components/chat/ChatBox.jsx", "components/chat/ContentProofNotice.jsx", "pages/creator/ManageUGCOrdersView.jsx" /* useChatThreadMobile.js is locked (protectedFlows) — left as is */, "pages/creator/CreatorUGCMobile.jsx", "components/admin/WhatsNewManager.jsx"]) {
      const s = read(f);
      const calls = s.match(/uploadToSignedUrl\([^\n]*/g) || [];
      expect(calls.length, f).toBeGreaterThan(0);
      for (const c of calls) expect(c, f).toContain('cacheControl: "31536000"');
    }
  });
});

import { ugcVideoAction, ugcOrderDoneAt, cleanupUgcVideos } from "../backend/admin_speed_routes";

describe("v462 · UGC videos removed 20 days after the order is finished", () => {
  const D = 86400e3, now = Date.parse("2026-12-31T00:00:00Z");
  const ago = (d) => new Date(now - d * D).toISOString();
  const base = { id: "ugcord_x1", status: "SUBMITTED", video_url: "ugc-videos/ugcord_x1/a.mp4" };
  it("running / submitted / completed-but-unpaid orders are never touched", () => {
    expect(ugcVideoAction({ ...base, updated_at: ago(90) }, now)).toBe(null);
    expect(ugcVideoAction({ ...base, status: "COMPLETED", updated_at: ago(90) }, now)).toBe(null);
  });
  it("released / cancelled / expired: warn at 13 days, delete at 20", () => {
    expect(ugcVideoAction({ ...base, escrow_released_at: ago(12) }, now)).toBe(null);
    expect(ugcVideoAction({ ...base, escrow_released_at: ago(19) }, now, true)).toBe(null);
    expect(ugcVideoAction({ ...base, escrow_released_at: ago(10) }, now)).toBe(null);
    expect(read("pages/brand/brandUgc/ApprovedPayoutModal.jsx")).toContain("Saved on Ybex for 20 days");
    expect(ugcVideoAction({ ...base, escrow_released_at: ago(14) }, now)).toBe("warn");
    expect(ugcVideoAction({ ...base, escrow_released_at: ago(14) }, now, true)).toBe(null);
    expect(ugcVideoAction({ ...base, escrow_released_at: ago(21) }, now)).toBe("delete");
    expect(ugcVideoAction({ ...base, cancelled_at: ago(40) }, now)).toBe("delete");
    expect(ugcVideoAction({ ...base, status: "EXPIRED", updated_at: ago(40) }, now)).toBe("delete");
  });
  it("links (Drive / Instagram) are never deleted", () => {
    expect(ugcVideoAction({ ...base, video_url: "https://drive.google.com/x", escrow_released_at: ago(90) }, now)).toBe(null);
    expect(ugcOrderDoneAt({ status: "SUBMITTED" })).toBe(0);
  });
  it("cleanup removes only that order's ugc-videos folder and warns both sides", async () => {
    const removed = [], notes = [], store = {};
    const client = {
      from: (t) => t === "ugc_orders"
        ? { select: () => ({ or: () => ({ limit: async () => ({ data: [
            { ...base, id: "old1", video_url: "ugc-videos/old1/v.mp4", brand_id: "b", creator_id: "c", escrow_released_at: ago(21) },
            { ...base, id: "mid1", video_url: "ugc-videos/mid1/v.mp4", brand_id: "b", creator_id: "c", escrow_released_at: ago(15) },
          ] }) }) }) }
        : { insert: (row) => { notes.push(row); return Promise.resolve({}); } },
      storage: { from: (b) => ({
        list: async (folder) => ({ data: [{ id: "1", name: "v.mp4" }, { id: "2", name: "v2.mp4" }] }),
        remove: async (paths) => { removed.push([b, ...paths]); return { error: null }; },
      }) },
    };
    const r = await cleanupUgcVideos(client, { get: async (k) => store[k], set: async (k, v) => { store[k] = v; } }, now);
    expect(r.deleted).toEqual(["old1"]);
    expect(r.warned).toEqual(["mid1"]);
    expect(removed).toEqual([["content-submissions", "ugc-videos/old1/v.mp4", "ugc-videos/old1/v2.mp4"]]);
    expect(notes.map((n) => n.user_id).sort()).toEqual(["b", "c"]);
    expect(notes[0].type).toBe("ugc_video_expiring");
  });
});

import { withClosedBriefs } from "./pages/creator/creatorUgc/BriefStickyBar";

describe("v460 · closed briefs stay listed for creators, can't be claimed", () => {
  it("open briefs first, closed after, no duplicates, flagged", () => {
    const r = withClosedBriefs({ data: [{ id: "a" }] }, { data: [{ id: "a" }, { id: "b", status: "CLOSED" }] });
    expect(r.data.map((b) => b.id)).toEqual(["a", "b"]);
    expect(r.data[1].applications_closed).toBe(true);
    expect(r.data[0].applications_closed).toBeUndefined();
    expect(withClosedBriefs({ data: [] }, { data: [] }).data).toEqual([]);
    expect(withClosedBriefs({ data: [] }, Promise.reject).data).toEqual([]);
  });
  it("cards show 'Applications closed' instead of claim; brand sees the same words", () => {
    // creator screens wait for Ravi's OK on the UGC flow lock (new GET /ugc/closed-briefs call) — see SESSIONS notes
    expect(read("pages/brand/BrandInstantUGC.jsx")).toContain('stageLabel = "Applications closed"');
    expect(read("pages/brand/BrandUGCMobile.jsx")).toContain("=== 'CLOSED' ? \"Applications closed\"");
    expect(fs.readFileSync(path.join(SRC, "../backend/campaignValue.ts"), "utf8")).toMatch(/router\.get\("\/ugc\/closed-briefs"/);
  });
});

import { closedLast } from "./pages/creator/creatorUgc/BriefStickyBar";
import { isShowcaseBrief, closedBriefRow } from "../backend/campaignValue";

describe("v461 · closed-brief list: shape + order", () => {
  it("claimable first, closed after, order kept inside each group", () => {
    const l = [{ id: 1, applications_closed: true }, { id: 2 }, { id: 3, applications_closed: true }, { id: 4 }];
    expect(closedLast(l).map((b) => b.id)).toEqual([2, 4, 1, 3]);
    expect(closedLast(null)).toEqual([]);
  });
  it("only real CLOSED briefs are shown; demo briefs never", () => {
    expect(isShowcaseBrief({ id: "brief_x", status: "CLOSED", brand_name: "Wefrnd" })).toBe(true);
    expect(isShowcaseBrief({ id: "brief_x", status: "OPEN" })).toBe(false);
    expect(isShowcaseBrief({ id: "brief_x", status: "CLOSED", brand_name: "Test Ravi" })).toBe(false);
    expect(isShowcaseBrief({ id: "brief_test_ravi_1", status: "CLOSED" })).toBe(false);
    expect(closedBriefRow({ id: "a", status: "OPEN" })).toMatchObject({ status: "CLOSED", applications_closed: true });
  });
  it("endpoint uses the same brand enrichment + privacy as the open list", () => {
    const s = fs.readFileSync(path.join(SRC, "../backend/campaignValue.ts"), "utf8");
    expect(s).toMatch(/enrichBriefsWithBrandProfiles\(rows\)/);
    expect(s).toMatch(/!viewer \? publicBrief\(b\) : isBriefOwner\(viewer, b\) \? b : briefForOutsider\(b\)/);
    expect(fs.readFileSync(path.join(SRC, "../backend/server.ts"), "utf8")).toMatch(/setupCampaignValueRoutes\(router, \{ supabase, privilegedSupabase, parseAuthUser, enrichBriefsWithBrandProfiles \}\)/);
  });
});

import { isFreshBrief } from "./pages/creator/creatorUgc/BriefStickyBar";
import { dueChip } from "./components/dashboard/CreatorDashboard";

describe("v463 · matches Ravi's reference designs (2h–2k)", () => {
  it("2h #37: 'New' only for briefs under 24 h old, soft violet chip, no shimmer", () => {
    const now = Date.parse("2026-11-20T12:00:00Z");
    expect(isFreshBrief({ created_at: "2026-11-20T01:00:00Z" }, now)).toBe(true);
    expect(isFreshBrief({ created_at: "2026-11-18T01:00:00Z" }, now)).toBe(false);
    expect(isFreshBrief({ created_at: "2026-11-10T01:00:00Z", relisted_at: "2026-11-20T10:00:00Z" }, now)).toBe(true);
    expect(isFreshBrief({}, now)).toBe(false);
    for (const f of ["pages/creator/CreatorUGCMobile.jsx", "pages/creator/CreatorUGCBrowse.jsx", "pages/brand/BrandUGCMobile.jsx"]) {
      const s = read(f);
      expect(s, f).toContain('bg-[#F5F0FF] text-[#7C3AED]');
      expect(s, f).not.toMatch(/ybex-shine[^"]*ugc-new-badge|data-testid="ugc-new-badge"><span className="relative z-\[2\]">NEW/);
    }
  });
  it("2h #16: selected pills are solid violet with a tick", () => {
    const a = read("components/campaigns/mobile/campaignCreate/AdvancedTargetingForm.jsx");
    expect(a).not.toContain('bg-[#F1E8FF] border border-[#DCC9FB] font-semibold text-[#6D28D9]');
    expect(a).toContain('{isSelected && <Check size={12}');
    expect(read("components/campaigns/mobile/MobileCampaignCreate.jsx")).toContain('{isSelected && <Check size={12}');
  });
  it("2h #33: due-date chip text", () => {
    const now = Date.parse("2026-11-20T06:00:00Z");
    expect(dueChip("2026-11-30", now)).toBe("Due 30 Nov");
    expect(dueChip("2026-11-01", now)).toBe("");
    expect(dueChip(null, now)).toBe("");
  });
  it("2h #17: status chips are plain sentence-case chips", () => {
    expect(read("pages/ugc/UgcOrders.jsx")).not.toMatch(/font-black uppercase tracking-widest/);
    expect(read("pages/ugc/UgcOrders.jsx")).not.toContain("Ybex Studio SLA");
  });
  it("2i #26/#42: reset screens + one error card", () => {
    const f = read("pages/auth/ForgotPassword.jsx"), r = read("pages/auth/ResetPassword.jsx");
    for (const s of [f, r]) { expect(s).toContain("bg-[#F2F2F7]"); expect(s).not.toMatch(/var\(--bg-primary\)|var\(--bg-secondary\)|Secure Your Account|Create New Password/); }
    expect(f).toContain("Send reset code");
    const p = read("components/PageErrorBoundary.jsx");
    expect(p).toContain("Try again. If it keeps happening, tell us and we'll fix it.");
    expect(p).toMatch(/data-testid="error-report">Report</);
    expect(read("components/ErrorBoundary.jsx")).toContain("<ErrorCard ");
  });
  it("2j #11/#15/#43: KYC rows, violation buttons, no 'Loading…' text", () => {
    const k = read("components/admin/KYCManager.jsx");
    expect(k).toContain('border-b border-[#EEF0F4]');
    expect(k).not.toMatch(/Profile summary[\s\S]{0,1500}text-blue-600/);
    const v = read("components/admin/SystemReports.jsx");
    expect(v).toContain("bg-[#DC2626] hover:bg-[#B91C1C] text-white");
    expect(v).not.toContain("Warn User");
    expect(read("components/ugc/BrandCancelOrderModal.jsx")).not.toContain(">Loading…<");
  });
  it("2k: FAQ / accordions grow open (yb-collapse 0.22 s)", () => {
    expect(fs.readFileSync(path.join(SRC, "index.css"), "utf8")).toMatch(/\.yb-collapse \{ display: grid; grid-template-rows: 0fr; transition: grid-template-rows 220ms/);
    for (const f of ["pages/creator/profileScreens/HelpScreen.jsx", "pages/help/HelpCategory.jsx", "components/payments/CreatorCodeCard.jsx", "components/profile/mobile/brand/PreferencesScreen.jsx"]) expect(read(f), f).toContain("yb-collapse");
  });
});

import { chatPushRecipients } from "../backend/chat_routes";
import { ugcClaimNotification } from "../backend/ugc_routes";

describe("v464 · chat + UGC claim pushes (Ravi approved 20 Nov)", () => {
  it("chat push goes to the other side; Support messages to both; never the sender", () => {
    const t = { brand_id: "b1", creator_id: "c1" };
    expect(chatPushRecipients("creator", t, "c1")).toEqual(["b1"]);
    expect(chatPushRecipients("brand", t, "b1")).toEqual(["c1"]);
    expect(chatPushRecipients("admin", t, "a9").sort()).toEqual(["b1", "c1"]);
    expect(chatPushRecipients("brand", { brand_id: "b1" }, "b1")).toEqual([]);
  });
  it("brand gets a claim notification that opens the order", () => {
    const n = ugcClaimNotification({ id: "br1", brand_id: "b1", title: "Unboxing reel", delivery_hours: 48 }, { id: "ugcord_x" }, { name: "Riya" }, "2026-11-20T00:00:00Z");
    expect(n).toMatchObject({ user_id: "b1", type: "UGC_CLAIMED", title: "Riya took your brief", redirect_path: "/brand/ugc/orders?order=ugcord_x" });
    expect(n.message).toContain('"Unboxing reel"');
    expect(Object.keys(n)).not.toContain("metadata"); // notifications table has no metadata column
  });
  it("wired in the routes", () => {
    expect(fs.readFileSync(path.join(SRC, "../backend/chat_routes.ts"), "utf8")).toMatch(/void pushToUsersNow\(to, chatPushPayload\(/);
    expect(fs.readFileSync(path.join(SRC, "../backend/ugc_routes.ts"), "utf8")).toMatch(/ugcClaimNotification\(brief, newOrder, user/);
  });
});
