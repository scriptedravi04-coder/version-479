import { describe, it, expect, beforeEach } from "vitest";
import { prerenderedArticle } from "./pages/blog/BlogPostDetail";
import { prerenderedPostList } from "./pages/blog/BlogIndex";

const setPage = (path, html) => {
  window.history.replaceState({}, "", path);
  document.body.innerHTML = `<div id="root"></div><noscript>${html}</noscript>`;
};
describe("v485: blog shows the server copy when the API fails", () => {
  beforeEach(() => { document.body.innerHTML = ""; });
  it("article", () => {
    setPage("/blog/fake-followers", `<article><h1>Check fake followers</h1><p>Short intro</p><h2>Step 1</h2><p>Body</p></article>`);
    const p = prerenderedArticle("fake-followers");
    expect(p?.title).toBe("Check fake followers");
    expect(p?.content).toContain("Step 1");
    expect(prerenderedArticle("other-slug")).toBeNull();
  });
  it("list", () => {
    setPage("/blog", `<h1>Ybex Journal</h1><ul><li><a href="https://ybexmedia.in/blog/a-b">A B</a> — intro</li></ul>`);
    expect(prerenderedPostList()).toEqual([{ id: "pre-a-b", slug: "a-b", title: "A B", excerpt: "intro", _prerendered: true }]);
  });
});
