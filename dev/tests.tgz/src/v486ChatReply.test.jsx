import { describe, it, expect, vi } from "vitest";
import React from "react";
import { render, screen } from "@testing-library/react";
import MobileMessageRow from "./components/chat/mobile/MobileMessageRow";
import TicketThread from "./components/help/TicketThread";

vi.mock("./lib/api", () => ({ api: { get: vi.fn(() => Promise.resolve({ data: [{ message_id: "a", sender_type: "ai", message: "Hi, Eva here", created_at: new Date().toISOString() }] })), post: vi.fn() } }));

describe("v486 chat: reply quote + seen ticks; Eva face on ticket replies", () => {
  it("quoted reply and ✓✓ Seen on my read message", () => {
    const m = { id: "m1", message_id: "m1", content: "ok done", message_type: "text", read: true, created_at: new Date().toISOString(), metadata: { reply_to: { message_id: "m0", text: "Send the draft by Friday", from: "Nova" } } };
    render(<MobileMessageRow message={m} isMine allMessages={[m]} onReply={() => {}} seenLabel />);
    expect(screen.getByTestId("chat-quote").textContent).toContain("Send the draft by Friday");
    expect(screen.getByTestId("msg-seen")).toBeTruthy();
    expect(screen.getByTestId("seen-label").textContent).toBe("Seen");
  });
  it("unread mine shows a single ✓", () => {
    const m = { id: "m2", content: "hi", message_type: "text", read: false, created_at: new Date().toISOString() };
    render(<MobileMessageRow message={m} isMine allMessages={[m]} />);
    expect(screen.getByTestId("msg-sent").textContent).toBe("✓");
  });
  it("Eva's ticket reply has her face", async () => {
    render(<TicketThread ticket={{ ticket_id: "t1", subject: "KYC", status: "OPEN" }} onBack={() => {}} />);
    expect(await screen.findByTestId("eva-ticket-reply")).toBeTruthy();
  });
});
